<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h3>hola mundo XD {{print_r($nombre)}}</h3>
	</body>
</html>