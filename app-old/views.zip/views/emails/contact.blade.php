<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		
		<h1>Que tal mi nombre es {{$nombre}}</h1>
		<p>
			{{$comments}}
		</p>

	Espero una pronta respuesta, mi correo es {{$email}} y mi número de teléfono es {{$telefono}} Saludos
	</body>
</html>