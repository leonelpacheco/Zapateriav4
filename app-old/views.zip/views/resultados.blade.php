@extends ('layout')


@section ('title')
{{$titulo}}
@stop
@section ('content')

<h1>

	Hola
</h1>

@stop
