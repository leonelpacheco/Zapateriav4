@extends ('layoutpage')


@section ('title')
Servicios
@stop
@section ('content')
<!-- start top_bg -->

    @section ('titulo')
Servicios
@stop</h2>

<!-- start main -->
<div class="main_bg">
<div class="wrap">
<div class="main">
	<div class="about">
			 <div class="cont-grid-img img_style">
	     		<img src="{{ asset('assets/images/about_pic.jpg') }}" alt="">
	     	</div>
	       <div class="cont-grid">
			       	<h4>Zapatería Yovanna</h4>
			       	<p class="para">Zapatería Yovanna, una empresa familiar, ubicada en Tecoh Yucatán a 30 km de la ciudad de Mérida, que desde hace ya más de 30 años se dedica a la fabricación y venta de calzado para dama.
 </p>
			       	<p class="para">En el presente esta empresa únicamente realiza la venta al público, teniendo algunos compradores al por mayor de forma esporádica, esto debido a que estos mayormente vienen desde Cancún.
</p>
	      	</div>
	      	<div class="clear"></div>
	    	<div class="about-p">
		    	<p class="para"><!--Lorem Ipsum is simply dummy text of the printing and typesetting industry., Lorem Ipsum  dummy text ever since dummy text of the printing and usings 1500s,Duis aute irure dolor in reprehenderit in voluptate velit esse when an,Lorem Ipsum has been the industry's standard dummy text ever since dummy text of the printing and usings 1500s,--> </p>
				<p class="para"><!--Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since dummy text of the printing and usings 1500s,Duis aute irure dolor in reprehenderit in voluptate velit Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since dummy text of the printing and usings 1500s,Duis aute irure dolor in reprehenderit in voluptate velit--></p>
				<p class="para"><!--There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.--></p>
				<div class="read_more">
					<a class="btn" href="details.html">Leer más</a>
				</div>
			</div>
	</div>
</div>
</div>
</div>

@stop
